//
//  TestAdderTask.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 26/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import "KSTask.h"

@interface TestAdderTask : KSTask
{
@private
    NSString *_inputParamName;
    NSString *_outputParamName;
}

@property (nonatomic,strong) NSString *inputParamName;
@property (nonatomic,strong) NSString *outputParamName;
@property (nonatomic) int numberToAdd;

- (instancetype)initWithInputParam:(NSString*)inputParamName
                    AndOutputParam:(NSString*)outputParamName
                         AndNumber:(int)numberToAdd;

- (void) execute;
@end
