//
//  KSSyncMetaInfo.h
//  KonySyncV2
//
//  Created by Prashant Panchal on 27/02/17.
//  Copyright © 2017 Kony. All rights reserved.
//

@interface KSSyncMetaInfo: NSObject

/**
 * Method to get the current value for the LastGeneratedId for given Object Service
 **/
- (NSInteger) getLastGeneratedId:(NSError **)error;


/**
 * Method to get the current value for the replaySequencenumber for given Object Service
 **/
- (NSInteger) getReplaySequenceNumber:(NSError **)error;


/**
 * Method to get the current value for the replaySequencenumber for given Object Service
 **/
- (NSInteger) getUploadSessionNumber:(NSError **)error;


/**
 * Initialize the MetaInfo Object for the Current Object Service
 **/
- (instancetype) init __attribute__((unavailable("Must use initWithName")));

- (instancetype) initWithObjectServiceName:(NSString *) name;

@end
