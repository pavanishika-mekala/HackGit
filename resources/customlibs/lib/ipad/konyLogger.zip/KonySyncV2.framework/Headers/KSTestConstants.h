//
//  KSTestConstants.h
//  KonySyncV2
//
//  Created by Harshini Bonam on 15/02/17.
//  Copyright © 2017 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#define FAQ_OBJECT_SERVICE_NAME @"SecondOS"

@interface KSTestConstants : NSObject

// url
#define LOGIN_URL @"http://10.10.12.84:7090/authService/100000002/login"
#define APP_CONFIG_URL @"http://10.10.12.84:7090/authService/100000002/appconfig"
#define APP_KEY @"X-Kony-App-Key"
#define APP_KEY_VALUE @"2404fcf06308d56be32fd423261ade16"
#define APP_SECRET @"X-Kony-App-Secret"
#define APP_SECRET_VALUE @"2908130dabc4270cb6ad8955fc1fd0dd"
#define CONTENT_TYPE @"Content-Type"
#define CONTENT_TYPE_VALUE @"application/json"
#define CATEGORY_GET @"http://10.10.12.84:8080/services/data/v1/SecondOS/objects/CATEGORY"
#define CRUD_OPTION_PRIMARY_KEYS @"primaryKeys"
#define CRUD_OPTION_WHERE_CONDITION @"whereCondition"
#define CRUD_OPTION_ORDERBY_MAP @"orderByMap"
#define OBJECT_CATEGORY @"CATEGORY"
#define OBJECT_TEST_PK_COMP @"TEST_PK_COMP"
#define OBJECT_SERVICE_METADATA_URL @"http://10.10.12.84:7090/services/metadata/v1/SecondOS"
#define OBJECT_SERVICE_BASE_URL @"http://10.10.12.84:7090/services/data/v1/SecondOS"


// table names
#define CATEGORY_TABLE_NAME @"CATEGORY"
#define CATEGORY2_TABLE_NAME @"CATEGORY2"
#define CATEGORY3_TABLE_NAME @"CATEGORY3"

#define objectServicesContextForTest \
\
 @{ FAQ_OBJECT_SERVICE_NAME: @{\
    @"version": @"1.0",\
    @"url": OBJECT_SERVICE_BASE_URL,\
    @"metadata_url": OBJECT_SERVICE_METADATA_URL,\
    @"type": @"objectsvc"}}

#define OBJECT_SERVICE_METADATA_JUNK_URL @"http://10.10.12.84:7090/services/metadata/v1/SecondOS_junk"
#define OBJECT_SERVICE_BASE_JUNK_URL @"http://10.10.12.84:7090/services/data/v1/SecondOS_junk"

#define objectServicesContextForNegativeTests \
\
@{ FAQ_OBJECT_SERVICE_NAME: @{\
@"version": @"1.0",\
@"url": OBJECT_SERVICE_BASE_JUNK_URL,\
@"metadata_url": OBJECT_SERVICE_METADATA_JUNK_URL,\
@"type": @"objectsvc"}}

#define objectServiceContextWithOneValidAndOneInvalidServiceForNegativeTestcases \
\
@{ FAQ_OBJECT_SERVICE_NAME: @{\
@"version": @"1.0",\
@"url": OBJECT_SERVICE_BASE_URL,\
@"metadata_url": OBJECT_SERVICE_METADATA_URL,\
@"type": @"objectsvc"}, \
@"SecondOS_junk": @{\
@"version": @"1.0",\
@"url": OBJECT_SERVICE_BASE_JUNK_URL,\
@"metadata_url": OBJECT_SERVICE_METADATA_JUNK_URL,\
@"type": @"objectsvc"}}


#define objectServicesContextForManyToOneTest \
\
@{ @"FirstOS": @{\
@"version": @"1.0",\
@"url": @"http://10.10.12.84:7090/services/data/v1/FirstOS",\
@"metadata_url": @"http://10.10.12.84:7090/services/metadata/v1/FirstOS",\
@"type": @"objectsvc"}}

#define EXPECTATION_TIMEOUT_IN_SECONDS 1200


@end
