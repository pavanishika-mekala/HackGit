//
//  ApplicationSync.h
//  KonySyncV2
//
//  Created by Chirag Mantri on 15/02/17.
//  Copyright © 2017 Kony. All rights reserved.
//
#import <Foundation/Foundation.h>

#import "KSConstants.h"

@interface ApplicationSync : NSObject

/**
 Preventing object creation for ApplicationSync using init.
 */
- (instancetype)init __attribute__((unavailable("Use static methods.")));

/**
 Method to set the claims token by MFSDK (KSAuthUtil)
 
 @param token Claims Token
 */
+ (void)setToken:(NSString *)token;

/**
 Static Function to call Application Sync Setup.
 
 @param objectServiceList Objects with metadata URLs in a Dictionary
 @param onSuccess onSuccess will be invoked on the Success of SyncSetup.
 @param onFailure onFailure will be invoked at the time of any error.
 */
+ (void)setupSync:(NSDictionary <NSString *, NSDictionary <NSString * , NSString *> *> *)objectServiceList
        onSuccess:(SuccessCompletionHandler)onSuccess
        onFailure:(FailureCompletionHandler)onFailure;

/**
 Static function to remove all tables for a Application
 
 @param onSuccess onSuccess will be invoked on the Successfull removal of all tables of an Application.
 @param onFailure onFailure will be invoked if all tables are not removed.
 */
+ (void)drop:(SuccessCompletionHandler)onSuccess
   onFailure:(FailureCompletionHandler)onFailure;

/**
 Resets application's sync database. This is done by dropping all tables followed by setup at at application level.
 
 @param objectServiceList Objects with metadata URLs in a Dictionary
 @param onSuccess onSuccess will be invoked on the Success of SyncReset.
 @param onFailure onFailure will be invoked at the time of any error.
 */
+ (void)reset:(NSDictionary <NSString *, NSDictionary <NSString * , NSString *> *> *)objectServiceList
    onSuccess:(SuccessCompletionHandler)onSuccess
    onFailure:(FailureCompletionHandler)onFailure;

/**
 Static function for rollback Application to its previous sync state
 
 @param onSuccess onSuccess will be invoked on the Successfull rollback at Application level.
 @param onFailure onFailure will be invoked if rollback failed at Application level
 */
+ (void)rollback:(SuccessCompletionHandler)onSuccess
       onFailure:(FailureCompletionHandler)onFailure;

@end
